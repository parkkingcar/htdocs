
<?php
phpinfo();
?>

