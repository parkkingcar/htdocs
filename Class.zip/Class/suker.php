<!DOTYPE html>
<html>
<head>
    <title>Suker</title>
    <html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
    <link href="buyagrade.css" type="text/css" rel="stylesheet">
</head>
<body>

<?php
function isCardRight($card)
{
    $flag = true;
    $number = 0;
    $space = 0;
    $other = 0;

    for($i = 0; $i < strlen($card); $i++){
        $asci = ord($card[$i]);

        if($asci >= 48 && $asci <=57) $number++;
        else if($asci == 45){
            if($i != 4 || $i != 9 || $i != 14) $flag = false;
            $space++;
        }
        else $other++;
    }

    if($other != 0) return false;
    else if($number == 16 && $space == 3 && flag) return true;
    else if($number == 16) return true;
    else return false;
}

$name = $_REQUEST['name'];
$section = $_REQUEST['Section'];
$card_com = $_REQUEST['Card_com'];
$creditCard = $_REQUEST['CreditCard'];

$isAll = true;
$isValidCard = true;

if(empty($name) || empty($section) || empty($card_com) || empty($creditCard)) $isAll = false;
else $isValidCard = isCardRight($card_com);

?>
<?php if($isAll && $isValidCard) {?>
    <h1>Thanks, sucker!</h1>
    <p>Your information has been recorded.</p>
    <dl>
        <dt>Name</dt>
        <dd><?=$name?></dd>

        <dt>Section</dt>
        <dd><?=$section?></dd>

        <dt>Credit Card</dt>
        <dd><?=$card_com?>(<?=$creditCard?>)</dd>
    </dl>
    <p>Here are all the sukers who have submitted here</p>
    <?php
    file_put_contents("suker.txt", "$name;$section;$card_com;$creditCard<br>\n", FILE_APPEND);
    $str = file_get_contents("suker.txt")
    ?>

    <p><?=$str?></p>
    <a href="lab4.html">Another</a>
<?php } else{ ?>
    <h1>Sorry</h1>
    <?php if($isValidCard == false){?>
        <p>You didn't provide a valid card number. <a href="lab4.html">Try again?</a></p>
        <?php  return;
    } ?>
    <p>You didn't fill out form completely <a href="lab4.html">Try again?</a></p>
<?php } ?>
</body>
</html>