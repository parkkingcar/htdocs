
function event(){
    document.getElementById("lookup").onclick = ClickBtn;
}

function ClickBtn(){
    let str = document.getElementById("term").value;
    const xmlhttp = new XMLHttpRequest();
    xmlhttp.onload = function() {
        document.getElementById("result").innerHTML = this.responseText;
    }
    xmlhttp.open("GET", "urban.php?q=" + str);
    xmlhttp.send();
}



window.onload = event;