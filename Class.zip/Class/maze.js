let isLoser = false;
let isClickBtn = false;

function mazeEvt(){
    document.getElementById('start').onclick = clickStartBtn;
    document.getElementById('end').onclick = clickEndBtn;
    document.getElementById('maze').onmouseleave = outOfMaze;
    let boundaries = document.getElementsByClassName('boundary');
    for(let i = 0; i < boundaries.length; i++) boundaries[i].onmouseover = hoverBlock;
}

function clickStartBtn(){
    isLoser = false;
    isClickBtn = true;
    let boundary = document.getElementsByClassName('boundary');
    for(let i = 0; i < boundary.length; i++){
        boundary[i].classList.remove("youlose");
    }
}

function clickEndBtn(){
    isClickBtn = false;
    if(isLoser === false) document.getElementById('alert').innerHTML = "Win!";
    else document.getElementById('alert').innerHTML = "Lose!";
}

function hoverBlock(){
    isLoser = true;
    let boundaries = document.getElementsByClassName('boundary');
    for(let i = 0; i < boundaries.length; i++){
        boundaries[i].classList.add("youlose");
    }
}

function outOfMaze(){
    isLoser = true;
    if(isClickBtn === true){
        let boundaries = document.getElementsByClassName('boundary');
        for(let i = 0; i < boundaries.length; i++) boundaries[i].classList.add("youlose");
        document.getElementById('alert').innerHTML = "Lose!";
    }
}

window.onload = mazeEvt;