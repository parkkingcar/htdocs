<!DOCTYPE html>
<html>

<head>
    <title>Web Programming</title>

    <style>
        body {
            background-color: powderblue;
        }
        h1{
            margin: 100px;
            padding-left: 700px;
            font-weight: bold;
            font-style: italic;
            font-family: Georgia;
            color: darkcyan;
            text-align: center;
        }
        h2{
            color: darkcyan;
            padding-left: 800px;
            font-weight: bold;
            font-family:  Georgia;
            font-size: 25px;
        }
        h3 {
            margin-top:0px;
            margin-left: 200px;
            list-style-type: lower-roman;
            color: darkblue;
            font-family: verdana;
            font-size: 25px;
        }
        p{
            margin-top:50px;
            margin-left: 200px;
            list-style-type: lower-roman;
            color: black;
            font-family: verdana;
            font-size: 25px;
            font-weight: bold;
        }
        dt{
            color: black;
            font-weight: bold;
            margin-left: 200px;
            margin-right: 200px;
            font-family: verdana;
            font-size: 20px;
            margin-bottom : 5px;
        }
        dd{
            font-family: Cursive;
            color: black;
            margin-left: 220px;
            margin-right: 220px;
            margin-bottom : 20px;
        }
        img{
            margin-left: 200px;
        }
        .border1{
            border : 10px solid lightblue;
            margin-bottom : 20px;
            margin-left: 200px;
            margin-right: 200px;
            background-color: white;
        }
    </style>
</head>
<div class="border1">
    <h3>190M Music Playlist Viewver</h3>
    <p>Search Through Your Playlists and Music</p>

    <?php
    function formatSize($bytes){
        $size = array('B', 'KB', 'GB', 'TB', 'PB', 'EB');
        $factor = floor((strlen($bytes - 1) / 3));

    }
    ?>
</div>

</html>
