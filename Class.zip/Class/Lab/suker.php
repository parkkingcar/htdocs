<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewfort" contet="width=device-width, inital-scale=1">
    <title>Suker</title>

    <style>
        *{
            margin: 0;
            padding: 0;
        }

        body{
            background-color: rebeccapurple;
        }

        .boxer{
            border: 10px solid gold;
            margin-left: 50px;
            margin-right: 50px;
            margin-top: 400px;
            margin-bottom: 300px;
            background-color: white;
        }

        .boxer h1, h2{
            font-weight: bold;
            text-align: center;
        }

        .boxer p {
            font-family: Arial;

        }
    </style>
</head>

<body>

<?php

function isCardRight($card)
{
    $flag = true;
    $number = 0;
    $space = 0;
    $other = 0;

    for($i = 0; $i < strlen($card); $i++){
        $asci = ord($card[$i]);

        if($asci >= 48 && $asci <=57) $number++;
        else if($asci == 45){
            if($i != 4 || $i != 9 || $i != 14) $flag = false;
            $space++;
        }
        else $other++;
    }

    if($other != 0) return false;
    else if($number == 16) return true;
    else if($number == 16 && $space == 3 && flag) return true;
    else return false;
}

$isAll = 1;
$isRightCard = true;
if(empty($_REQUEST["Name"]) || empty($_REQUEST["Section"]) || empty($_REQUEST["Credit"]) || empty($_REQUEST["Card"])){
    $isAll = 0;
}
else{
    $name = $_REQUEST["Name"];
    $section = $_REQUEST["Section"];
    $creditCardNumber = $_REQUEST["Credit"];
    $creditCard  = $_REQUEST["Card"];
    $isRightCard = isCardRight($creditCardNumber);
}

    ?>

<div class="boxer">
    <?php if($isAll == 1 && $isRightCard == true) { ?>
    <h1>Thank, sucker!</h1>
    <p>Your imformation has been recoreded.</p>
    <br>
    <p>Name</p>
    <p><?=$name ?></p>

    <p>Section</p>
    <p><?=$section?></p>

    <p>Credit Card</p>
    <p><?=$creditCardNumber?>(<?=$creditCard ?>)</p><br>
    <p>Here are all the suckers who have submitted here:<br></p>
     <?php
        file_put_contents("list.txt", "$name;$section;$creditCardNumber;$creditCard<br>\n", FILE_APPEND);
        $str = file_get_contents("list.txt");?>
        <p><?=$str ?></p>
    <?php } else{ ?>
    <h1 stype="margin: 120%;">Sorry</h1>
            <?php if($isRightCard == false){ ?>
                <p>You didn't provide a valid card number.<a href="lab4.html">Try again?</a></p>
                <?php return; } ?>
    <p>You didn't fill out the form completly.<a href="lab4.html">Try again?</a></p>
    <?php }?>
</div>
</body>
</html>
