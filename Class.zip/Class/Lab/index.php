<!DOCTYPE html>
<html>

<head>
    <title>Web Programming</title>
    <!--style-->
    <style>
        body {
            //background-image: url("7.jpg");
        }
        h1{
            margin: 100px;
            padding-left: 700px;
            font-weight: bold;
            font-style: italic;
            font-family: Georgia;
            color: darkcyan;
            text-align: center;
        }
        h2{
            color: darkcyan;
            padding-left: 800px;
            font-weight: bold;
            font-family:  Georgia;
            font-size: 25px;
        }
        h3 {
            margin-top:0;
            margin-left: 200px;
            list-style-type: lower-roman;
            color: darkblue;
            font-family: verdana;
            font-size: 25px;
        }
        p{
            margin-top:50px;
            margin-left: 200px;
            list-style-type: lower-roman;
            color: black;
            font-family: verdana;
            font-size: 25px;
            font-weight: bold;
        }
        dt{
            color: black;
            font-weight: bold;
            margin-left: 200px;
            margin-right: 200px;
            font-family: verdana;
            font-size: 20px;
            margin-bottom : 5px;
        }
        dd{
            font-family: Cursive;
            color: black;
            margin-left: 220px;
            margin-right: 220px;
            margin-bottom : 20px;
        }
        img{
            margin-left: 200px;
        }
        .border1{
            border : 10px solid lightblue;
            margin-bottom : 20px;
            margin-left: 200px;
            margin-right: 200px;}
        }
    </style>
</head>

<!--body part-->
<body>

<div class = "border1">
    <h3>190M Music Playlist Viewer</h3>
    <p>Search Through Your Playlists and Music</p>

    <?php
    function formatSize($bytes) {
        $size = array('B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB');
        $factor = floor((strlen($bytes) - 1) / 3);
        if($bytes <1024){
            return (int)$bytes."B";
        }else{
            return sprintf("%.2f", $bytes / pow(1024, $factor)) . @$size[$factor];
        }
    }
    $folder = "songs";
    foreach(scandir($folder) as $filename){
        if(strpos(basename($filename),".mp3")){
            $size = filesize("songs/$filename");
            $fs = formatSize($size);
            ?>
            <a href="songs/<?=$filename?>"title="mp3"/>
            <dd><img style="margin-left:0px;display:inline;" src="mp3icon.png" alt="song" width="25" height="25" /><?= $filename?> (<?=$fs?>)</dd>
            </a>
            <?php
        }
    }
    foreach(scandir($folder) as $filename){
        if(strpos(basename($filename),".txt")){
            ?>
            <a href="songs/<?=$filename?>">
                <dd><img style="margin-left:0px" src="txticon.png" alt="text" width="25" height="25" /><?= $filename?></dd>
            </a>
            <?php
        }
    }
    ?>
</div>

</body>

</html>