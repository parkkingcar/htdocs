<?php

$host = "localhost";
$user = "root";
$password = "rozenthal7";
$database = "myDB";

// create myDB
$conn = new mysqli($host, $user, $password, $database);


$conn->close();

?>

